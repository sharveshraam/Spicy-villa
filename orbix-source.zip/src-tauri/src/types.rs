﻿use serde::{Deserialize, Serialize};

#[derive(Deserialize, Debug)]
#[serde(rename = "WmiMonitorBrightness")]
#[serde(rename_all = "PascalCase")]
pub struct WmiMonitorBrightness {
    pub current_brightness: u8,
}

/// Raised by Windows whenever a display's brightness changes, by any means.
#[derive(Deserialize, Debug)]
#[serde(rename = "WmiMonitorBrightnessEvent")]
#[serde(rename_all = "PascalCase")]
pub struct WmiMonitorBrightnessEvent {
    pub brightness: u8,
}

#[derive(Clone, Serialize)]
pub struct AudioVisualizationData {
    pub frequencies: Vec<f32>,
}

#[derive(Serialize, Clone)]
pub struct MediaInfo {
    pub title: String,
    pub artist: String,
    pub is_playing: bool,
    pub has_media: bool,
    pub artwork: Option<Vec<String>>,
    #[serde(default)]
    pub position_ms: i64,
    #[serde(default)]
    pub duration_ms: i64,
    #[serde(default)]
    pub seek_enabled: bool,
    #[serde(default)]
    pub position_updated_at: u64,
}

pub enum SystemCommand {
    SetVolume(f32),
    MediaPlayPause,
    MediaNext,
    MediaPrevious,
    MediaSeek(i64),
    ToggleVisibility(bool),
}

#[derive(Clone, Copy, Deserialize, Debug)]
pub struct IntRect {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct AppInfo {
    pub name: String,
    pub path: String,
    pub icon: Option<String>,
    pub is_running: bool,
    pub hwnd: Option<isize>,
    pub executable: Option<String>,
    pub all_hwnds: Option<Vec<(isize, String)>>, // (hwnd, title)
}

#[derive(Clone, Serialize)]
pub struct BrightnessChangeEvent {
    pub brightness: u32,
}

#[derive(Clone, Serialize)]
pub struct VolumeChangeEvent {
    pub volume: f32,
    pub is_muted: bool,
}

#[derive(Clone, Serialize)]
pub struct WifiStatus {
    pub enabled: bool,
    pub connected: bool,
    pub ethernet_connected: bool,
}

#[derive(Clone, Serialize)]
pub struct AudioSessionInfo {
    pub pid: u32,
    pub name: String,
    pub process_path: Option<String>,
    pub volume: f32,
    pub is_muted: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SearchFileItem {
    pub name: String,
    pub path: String,
    pub is_dir: bool,
    pub ext: Option<String>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct AudioDeviceStatus {
    pub headphone_connected: bool,
    pub headphone_name: String,
    pub mic_connected: bool,
    pub mic_name: String,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct InternetStatus {
    pub connection_type: String,
    pub label: String,
    pub is_connected: bool,
    pub ethernet_connected: bool,
    pub wifi_connected: bool,
    pub wifi_enabled: bool,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct WifiNetworkEntry {
    pub ssid: String,
    pub signal_percent: u8,
    pub is_secure: bool,
    pub is_connected: bool,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct MicrophoneState {
    pub is_muted: bool,
    pub device_name: String,
}